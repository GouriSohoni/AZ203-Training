﻿namespace AdventureWorks.Web.Configuration
{
    public class Settings
    {
        public string BlobContainerUrl { get; set; }

        public bool CartAvailable { get; set; }

        public string UniqueIdentifier { get; set; }
    }
}